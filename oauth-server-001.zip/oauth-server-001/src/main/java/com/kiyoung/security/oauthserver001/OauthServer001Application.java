package com.kiyoung.security.oauthserver001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OauthServer001Application {

	public static void main(String[] args) {
		SpringApplication.run(OauthServer001Application.class, args);
	}
}
