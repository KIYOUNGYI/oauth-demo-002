package com.kiyoung.security.oauthapiserver001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OauthApiServer001Application {

	public static void main(String[] args) {
		SpringApplication.run(OauthApiServer001Application.class, args);
	}
}
